from gen_ai_hub.proxy.langchain import ChatOpenAI
from gen_ai_hub.proxy.core.proxy_clients import get_proxy_client
import os

class AICoreLLMClient:
    def __init__(self, model_name: str = "gpt-4o"):
        self.proxy_client = get_proxy_client("gen-ai-hub")
        self.model = ChatOpenAI(
            proxy_client=self.proxy_client,
            proxy_model_name=model_name,
            temperature=0.1
        )
    
    def invoke(self, prompt: str) -> str:
        response = self.model.invoke(prompt)
        return response.content

class LocalLLMClient:
    def __init__(self, api_key: str = None, base_url: str = None, model: str = "gpt-4o"):
        from openai import OpenAI
        self.client = OpenAI(
            api_key=api_key or os.getenv("OPENAI_API_KEY"),
            base_url=base_url
        )
        self.model = model
    
    def invoke(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1
        )
        return response.choices[0].message.content

class MockLLMClient:
    def invoke(self, prompt: str) -> str:
        if "root cause" in prompt.lower() or "analyze" in prompt.lower():
            return """Root Cause Analysis:
            
1. PRIMARY CAUSE: RFC connection timeout to remote system
   - The job attempted to call RFC destination CLNT100 which failed after 30 seconds
   - Error code: RFC_COMMUNICATION_FAILURE

2. CONTRIBUTING FACTORS:
   - Network latency between application servers
   - Remote system may be under heavy load

3. RECOMMENDATION:
   - Check RFC destination configuration in SM59
   - Verify remote system availability
   - Consider increasing timeout parameters"""
        
        return "Analysis complete. No specific issues identified."

def get_llm_client(mode: str = "mock", **kwargs):
    if mode == "aicore":
        return AICoreLLMClient(**kwargs)
    elif mode == "local":
        return LocalLLMClient(**kwargs)
    else:
        return MockLLMClient()
