# sap-cashflow-mcp-server

Custom MCP server for SAP Joule Studio agents — exposes 2 tools that
explain custom AutoTS cashflow forecasts produced by the UC2 pipeline.

This is the UC2.7 Joule Agent companion server. It is the cashflow-
domain twin of `sap-procurement-mcp-server` (Lab A), built with the
same FastMCP + gen-ai-hub-sdk pattern.

## Scope

The server exposes 2 MCP tools, consumable by a Joule Agent via an
MCP destination:

| Tool | Purpose |
|---|---|
| `explain_cashflow_full` | Calls UC2.6 Step 4 `/v2/explain` deployment, returns structured SHAP attribution data (forecast, top features, nearest window, surrogate caveat). Narrative is deliberately stripped. |
| `explain_cashflow_template` | Calls AI Core Orchestration with the registered Prompt Template `cashflow-forecast/cashflow-explainer-system/0.0.2` (UC2.6 Part B), returns narrative text only. |

The agent decides which tool(s) to call based on user intent. The
two-tool design separates SHAP-data retrieval (deterministic, structured)
from narrative generation (LLM, runtime-swappable via Prompt Management).

## Architecture

```
Joule Studio Agent
        |
        v  (Streamable HTTP via BTP destination sap-mcp-cashflow)
   FastMCP server (this repo, deployed to Kyma)
        |
        +--> Tool 8 --> AI Core /v2/explain  (UC2.6 Step 4 deployment)
        |                     |
        |                     +--> AutoTS predict (cashflow-forecast-serve)
        |                     +--> SHAP summary (artifact mount)
        |                     +--> GPT-4o narrative (stripped before return)
        |
        +--> Tool 9 --> AI Core Orchestration
                              |
                              +--> Prompt Template v0.0.2
                              +--> GPT-4o
                              +--> narrative (returned)
```

## Components

| Path | Purpose |
|---|---|
| `src/server.py` | FastMCP bootstrap, registers the 2 tools |
| `src/aicore/inference.py` | Reusable client for any AI Core deployment by ID |
| `src/aicore/orchestration.py` | Reusable client for Prompt-Template-driven Orchestration calls |
| `src/tools/explain_cashflow_full.py` | Tool 8 — strips narrative, caps top_n, rounds floats |
| `src/tools/explain_cashflow_template.py` | Tool 9 — formats top_features for `{{?top_features}}` placeholder |
| `tests/test_tools_local.py` | End-to-end smoke against live AI Core |
| `Dockerfile` | python:3.11-slim, UID 1000, port 8080, FASTMCP_STATELESS_HTTP=true |
| `deploy/manifest.yaml` | Kyma Secret + Deployment + Service + APIRule |
| `deploy/btp-destination.md` | BTP Destination spec for `sap-mcp-cashflow` |
| `deploy/joule-agent-config.md` | All Joule Studio agent-builder text |

## Quick start

### 1. Local smoke test

```bash
cp .env.example .env
# Populate AICORE_*, ORCHESTRATION_DEPLOYMENT_ID

python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python -m tests.test_tools_local
```

Both tools must pass before continuing to deploy.

### 2. Build and push image

```bash
docker build -t srini117us/sap-cashflow-mcp-server:v1 .
docker push srini117us/sap-cashflow-mcp-server:v1
```

### 3. Deploy to Kyma

```bash
# Edit deploy/manifest.yaml — replace REPLACE_* placeholders
kubectl apply -n <your-namespace> -f deploy/manifest.yaml
kubectl get apirule sap-cashflow-mcp-server -n <your-namespace>
# Note the host URL from the APIRule status — use it in the BTP destination
```

### 4. Create BTP destination

Follow `deploy/btp-destination.md` exactly. The three additional
properties are non-negotiable; without them the destination won't
appear in Joule Studio.

### 5. Build the Joule Agent

Follow `deploy/joule-agent-config.md`. Paste the text into Joule Studio
verbatim. Run all 5 test prompts and capture screenshots.

## Reference

| | Value |
|---|---|
| Tool 8 deployment | `d00c85f445274f70` (UC2.6 Step 4) |
| Tool 9 prompt template | `cashflow-forecast/cashflow-explainer-system/0.0.2` (UC2.6 Part B) |
| Tool 9 template UUID | `1ad15091-ad26-43a6-810e-77011234a04c` |
| Companies served | 1010, 1710 |
| Resource group (explain) | ml-training |
| Resource group (orchestration) | ai-launchpad |
| SDK | generative-ai-hub-sdk 3.1.1 |
| MCP transport | Streamable HTTP (Joule requirement) |
| Joule tool response cap | 10,240 bytes (enforced via top_n cap and float rounding) |

## SAP-native pass

Per UC2.7's SAP-native-first evaluation, four options were considered
before selecting custom MCP server + custom Joule Agent:

1. **SAP-published Cash Management Joule Agent** — ruled out: BETA per
   SAP learning portal disclaimer, requires S/4HANA Cloud Public
   Edition (landscape uses Private Edition), scope is bank-statement
   reconciliation not custom-ML-forecast explainability.
2. **SAP Build Store cash-related templates** — searched for "Cash" in
   Build Store, six results, zero applicable Joule Agent templates
   (three deprecated, two joint-venture-specific Process Automation,
   one paid third-party RPA).
3. **Joule Skill calling Orchestration directly via destination** —
   viable for the narrative path alone but cannot do tool selection
   between SHAP-data retrieval and narrative rendering. Inferior to
   an Agent for this use case.
4. **Custom Joule Agent + custom MCP server** (selected) — pattern
   documented in SAP's "From Prompt to Production: Creating an MCP
   Server for Joule Studio Using AI Core" blog. Same pattern as the
   Procurement Risk Analyzer Agent extension already proven in Lab A.
